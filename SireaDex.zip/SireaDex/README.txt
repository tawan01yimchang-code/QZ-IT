SireaDex - Android 13+ (API 33+)
1) เปิดโฟลเดอร์นี้ใน Android Studio (Koala ขึ้นไป) -> Sync -> Build > Build APK
2) ติดตั้งแอป Shizuku แล้วกด Start
3) เปิด SireaDex -> อนุญาต Shizuku -> ตั้ง W x H / DPI -> เปิด Desktop Mode
4) เพิ่มปุ่ม SireaDex ในแผงการตั้งค่าด่วน (ศูนย์ควบคุม)
