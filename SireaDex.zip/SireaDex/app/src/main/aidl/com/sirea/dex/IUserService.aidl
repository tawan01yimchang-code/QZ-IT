package com.sirea.dex;

interface IUserService {
    void destroy() = 16777114;
    String exec(String command) = 1;
}
