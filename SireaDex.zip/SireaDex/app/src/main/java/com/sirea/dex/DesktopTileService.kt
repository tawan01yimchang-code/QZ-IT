package com.sirea.dex

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import kotlin.concurrent.thread

/** Quick Settings ("control center") tile: tap = Desktop Mode on + saved size/dpi, tap again = off + reset. */
class DesktopTileService : TileService() {

    override fun onStartListening() { refresh() }

    private fun setState(active: Boolean, label: String? = null) {
        qsTile?.apply {
            state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            this.label = label ?: getString(R.string.tile_label); updateTile()
        }
    }

    private fun refresh() {
        if (!Shell.granted) { setState(false, getString(R.string.tile_need_shizuku)); return }
        Shell.bind(this) { thread { val on = Desktop.isOn(); setState(on) } }
    }

    override fun onClick() {
        if (!Shell.granted) { setState(false, getString(R.string.tile_need_shizuku)); return }
        Shell.bind(this) {
            thread {
                val prefs = Prefs(this)
                if (Desktop.isOn()) {
                    Desktop.disable(); Desktop.resetAll(prefs.display); setState(false)
                } else {
                    Desktop.enable(this)
                    if (prefs.applyScreen) {
                        Desktop.setSize(prefs.width, prefs.height, prefs.display)
                        Desktop.setDensity(prefs.dpi, prefs.display)
                    }
                    setState(true)
                }
            }
        }
    }
}
