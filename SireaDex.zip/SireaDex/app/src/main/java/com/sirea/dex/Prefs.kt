package com.sirea.dex

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("sirea", Context.MODE_PRIVATE)
    var width: Int get() = p.getInt("w", 1920); set(v) = p.edit().putInt("w", v).apply()
    var height: Int get() = p.getInt("h", 1080); set(v) = p.edit().putInt("h", v).apply()
    var dpi: Int get() = p.getInt("dpi", 240); set(v) = p.edit().putInt("dpi", v).apply()
    var display: Int get() = p.getInt("d", 0); set(v) = p.edit().putInt("d", v).apply()
    var applyScreen: Boolean get() = p.getBoolean("as", true); set(v) = p.edit().putBoolean("as", v).apply()
}
