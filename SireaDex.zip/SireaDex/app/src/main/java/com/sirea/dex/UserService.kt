package com.sirea.dex

import androidx.annotation.Keep
import kotlin.system.exitProcess

/** Runs inside the Shizuku process with shell (adb) privileges. */
class UserService() : IUserService.Stub() {
    @Keep constructor(context: android.content.Context) : this()

    override fun destroy() { exitProcess(0) }

    override fun exec(command: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        (out + err).trim() + if (code != 0) "\n[exit $code]" else ""
    } catch (t: Throwable) { "ERROR: ${t.message}" }
}
