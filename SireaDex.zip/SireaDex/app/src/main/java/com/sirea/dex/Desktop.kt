package com.sirea.dex

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/**
 * Desktop-mode logic. Only devices that actually expose a desktop / freeform mode are accepted.
 * Brand-specific steps are best effort: every step's output is returned so the UI can show it.
 */
object Desktop {
    enum class Brand(val label: String) {
        SAMSUNG("Samsung DeX"), XIAOMI("Xiaomi / HyperOS PC mode"), MOTOROLA("Motorola Ready For"),
        LENOVO("Lenovo PC mode"), HUAWEI("Huawei / Honor PC mode"), AOSP("Android Desktop Mode"), NONE("")
    }

    fun brand(): Brand = when (Build.MANUFACTURER.lowercase()) {
        "samsung" -> Brand.SAMSUNG
        "xiaomi", "redmi", "poco" -> Brand.XIAOMI
        "motorola" -> Brand.MOTOROLA
        "lenovo" -> Brand.LENOVO
        "huawei", "honor" -> Brand.HUAWEI
        else -> Brand.AOSP
    }

    private fun has(ctx: Context, pkg: String) =
        runCatching { ctx.packageManager.getPackageInfo(pkg, 0); true }.getOrDefault(false)

    /** Returns the detected desktop mode, or Brand.NONE if this device has none. */
    fun detect(ctx: Context): Brand {
        val freeform = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
        return when {
            has(ctx, "com.sec.android.desktopmode.uiservice") -> Brand.SAMSUNG
            freeform || Build.VERSION.SDK_INT >= 35 -> brand().let { if (it == Brand.SAMSUNG) Brand.AOSP else it }
            else -> Brand.NONE
        }
    }

    private val on = listOf(
        "settings put global enable_freeform_support 1",
        "settings put global freeform_window_management 1",
        "settings put global force_resizable_activities 1",
        "settings put global force_desktop_mode_on_external_displays 1",
        "settings put global development_settings_enabled 1"
    )
    private val off = listOf(
        "settings put global force_desktop_mode_on_external_displays 0",
        "settings put global freeform_window_management 0",
        "settings put global enable_freeform_support 0",
        "settings put global force_resizable_activities 0"
    )
    private val samsungLaunch = listOf(
        "am start -a com.samsung.android.desktopmode.action.DEX_SETTINGS",
        "am start -n com.sec.android.desktopmode.uiservice/.settings.DexSettingsActivity",
        "am start -a com.samsung.settings.DEX_SETTINGS",
        "am start -n com.android.settings/com.samsung.android.settings.desktopmode.DesktopModeSettings"
    )

    fun isOn(): Boolean = Shell.exec("settings get global force_desktop_mode_on_external_displays").trim() == "1"

    fun enable(ctx: Context): String {
        val log = StringBuilder()
        on.forEach { log.appendLine("$ $it").appendLine(Shell.exec(it)) }
        if (detect(ctx) == Brand.SAMSUNG) {
            for (c in samsungLaunch) {
                val r = Shell.exec(c)
                log.appendLine("$ $c").appendLine(r)
                if (!r.contains("Error", true) && !r.contains("exit")) break
            }
        }
        return log.toString().trim()
    }

    fun disable(): String {
        val log = StringBuilder()
        off.forEach { log.appendLine("$ $it").appendLine(Shell.exec(it)) }
        return log.toString().trim()
    }

    // ---- display (wm) ----
    private fun d(id: Int) = if (id == 0) "" else " -d $id"
    fun setSize(w: Int, h: Int, display: Int) = Shell.exec("wm size ${w}x$h${d(display)}")
    fun setDensity(dpi: Int, display: Int) = Shell.exec("wm density $dpi${d(display)}")
    fun resetAll(display: Int) = Shell.exec("wm size reset${d(display)}; wm density reset${d(display)}")
    fun currentSize(display: Int) = Shell.exec("wm size${d(display)}")
    fun currentDensity(display: Int) = Shell.exec("wm density${d(display)}")
}
