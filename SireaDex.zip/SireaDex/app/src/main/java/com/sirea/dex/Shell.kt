package com.sirea.dex

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/** Single access point to Shizuku, shared by the activity and the Quick Settings tile. */
object Shell {
    @Volatile var service: IUserService? = null
    private var binding = false
    private val waiters = mutableListOf<() -> Unit>()
    var onStateChanged: (() -> Unit)? = null

    val running get() = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
    val granted get() = running && !Shizuku.isPreV11() &&
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    val ready get() = granted && service != null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            service = IUserService.Stub.asInterface(b); binding = false
            waiters.toList().also { waiters.clear() }.forEach { it() }
            onStateChanged?.invoke()
        }
        override fun onServiceDisconnected(n: ComponentName?) { service = null; onStateChanged?.invoke() }
    }

    fun bind(ctx: Context, then: (() -> Unit)? = null) {
        if (then != null) { if (ready) { then(); return } else waiters += then }
        if (!granted || service != null || binding) return
        binding = true
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, UserService::class.java.name))
            .daemon(false).processNameSuffix("sirea").version(1)
        Shizuku.bindUserService(args, conn)
    }

    fun requestPermission(code: Int) = Shizuku.requestPermission(code)

    /** Blocking - call from a background thread. */
    fun exec(cmd: String): String = service?.exec(cmd) ?: "ERROR: Shizuku not connected"
}
