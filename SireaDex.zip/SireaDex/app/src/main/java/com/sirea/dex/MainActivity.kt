package com.sirea.dex

import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sirea.dex.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs
    private var displayIds = listOf(0)

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> Shell.bind(this); runOnUiThread { ui() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { Shell.bind(this); runOnUiThread { ui() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { ui() } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        prefs = Prefs(this)

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shell.onStateChanged = { runOnUiThread { ui() } }

        b.etW.setText(prefs.width.toString()); b.etH.setText(prefs.height.toString()); b.etDpi.setText(prefs.dpi.toString())
        b.swScreen.isChecked = prefs.applyScreen

        b.btnShizuku.setOnClickListener {
            when {
                !Shell.running -> openShizuku()
                !Shell.granted -> Shell.requestPermission(100)
                else -> Shell.bind(this)
            }
        }
        listOf(b.p720 to Triple(1280, 720, 160), b.p1080 to Triple(1920, 1080, 240),
               b.p1440 to Triple(2560, 1440, 280), b.p4k to Triple(3840, 2160, 320)).forEach { (v, t) ->
            v.setOnClickListener {
                b.etW.setText(t.first.toString()); b.etH.setText(t.second.toString()); b.etDpi.setText(t.third.toString())
            }
        }
        b.btnApplyScreen.setOnClickListener { exec { applyScreen() } }
        b.btnReset.setOnClickListener { exec { log("wm reset", Desktop.resetAll(prefs.display)) } }
        b.btnOn.setOnClickListener {
            if (!savePrefs()) return@setOnClickListener
            exec {
                log("Desktop ON", Desktop.enable(this))
                if (prefs.applyScreen) applyScreen()
            }
        }
        b.btnOff.setOnClickListener {
            exec { log("Desktop OFF", Desktop.disable()); if (prefs.applyScreen) log("wm reset", Desktop.resetAll(prefs.display)) }
        }
        b.btnTileHint.setOnClickListener { Toast.makeText(this, R.string.tile_hint, Toast.LENGTH_LONG).show() }
        setupDisplays(); ui()
    }

    override fun onResume() { super.onResume(); Shell.bind(this); ui() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shell.onStateChanged = null
        super.onDestroy()
    }

    private fun setupDisplays() {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val ds = dm.displays
        displayIds = ds.map { it.displayId }
        b.spDisplay.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            ds.map { "#${it.displayId}  ${it.name}" })
        b.spDisplay.setSelection(displayIds.indexOf(prefs.display).coerceAtLeast(0))
    }

    private fun savePrefs(): Boolean {
        val w = b.etW.text.toString().toIntOrNull(); val h = b.etH.text.toString().toIntOrNull()
        val d = b.etDpi.text.toString().toIntOrNull()
        if (w == null || h == null || d == null || w < 320 || h < 320 || d < 72 || d > 960) {
            Toast.makeText(this, R.string.bad_values, Toast.LENGTH_SHORT).show(); return false
        }
        prefs.width = w; prefs.height = h; prefs.dpi = d
        prefs.display = displayIds.getOrElse(b.spDisplay.selectedItemPosition) { 0 }
        prefs.applyScreen = b.swScreen.isChecked
        return true
    }

    /** Runs on a background thread. Values are saved on the UI thread before calling. */
    private fun applyScreen() {
        log("wm size", Desktop.setSize(prefs.width, prefs.height, prefs.display))
        log("wm density", Desktop.setDensity(prefs.dpi, prefs.display))
    }

    private fun exec(block: () -> Unit) {
        if (!Shell.ready) { Toast.makeText(this, R.string.need_shizuku, Toast.LENGTH_SHORT).show(); return }
        if (!savePrefs()) return
        thread { block(); runOnUiThread { ui() } }
    }

    private fun log(title: String, out: String) = runOnUiThread {
        b.tvLog.append("> $title\n${out.ifBlank { "OK" }}\n\n")
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) startActivity(i)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
    }

    /** Whole UI is gated by Shizuku: nothing is usable until it is connected. */
    private fun ui() {
        val ready = Shell.ready
        b.tvShizuku.setText(when {
            !Shell.running -> R.string.shz_not_running
            !Shell.granted -> R.string.shz_no_perm
            !ready -> R.string.shz_connecting
            else -> R.string.shz_ok
        })
        b.btnShizuku.visibility = if (ready) View.GONE else View.VISIBLE
        b.btnShizuku.setText(if (!Shell.running) R.string.open_shizuku else R.string.grant)
        b.controls.alpha = if (ready) 1f else 0.4f
        listOf(b.btnOn, b.btnOff, b.btnApplyScreen, b.btnReset, b.etW, b.etH, b.etDpi, b.spDisplay,
            b.swScreen, b.p720, b.p1080, b.p1440, b.p4k).forEach { it.isEnabled = ready }

        val brand = Desktop.detect(this)
        if (brand == Desktop.Brand.NONE) {
            b.tvDevice.setText(R.string.unsupported)
            listOf(b.btnOn, b.btnOff).forEach { it.isEnabled = false }
        } else b.tvDevice.text = getString(R.string.supported_fmt, android.os.Build.MANUFACTURER, android.os.Build.MODEL, brand.label)

        if (ready) thread {
            val st = Desktop.isOn(); val size = Desktop.currentSize(prefs.display); val dpi = Desktop.currentDensity(prefs.display)
            runOnUiThread { b.tvState.text = getString(R.string.state_fmt, if (st) "ON" else "OFF", size, dpi) }
        }
    }
}
