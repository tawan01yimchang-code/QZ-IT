package com.rattew.optionapiqz

/**
 * One Developer-Options style entry.
 * read = command whose output tells the current state (null = write-only, state cached locally).
 */
class Opt(
    val title: String,
    val summary: String,
    val read: String?,
    val isOn: (String) -> Boolean,
    val on: String,
    val off: String,
    val choices: List<String>? = null,
    val setChoice: ((String) -> String)? = null,
    val persist: Boolean = true,   // include in the root boot module when ON
)

private const val REFRESH = "service call activity 1599295570 >/dev/null 2>&1"

private fun setting(title: String, summary: String, ns: String, key: String, onV: String = "1", offV: String = "0") =
    Opt(title, summary, "settings get $ns $key", { it.trim() == onV },
        "settings put $ns $key $onV", "settings put $ns $key $offV")

private fun prop(title: String, summary: String, key: String, onV: String, offV: String) =
    Opt(title, summary, "getprop $key", { it.trim() == onV },
        "setprop $key $onV; $REFRESH", "setprop $key $offV; $REFRESH")

private fun scale(title: String, key: String) =
    Opt(title, "Tap to choose a scale", "settings get global $key",
        { true }, "settings put global $key 0.5", "settings put global $key 1",
        choices = listOf("0", "0.5", "1", "1.5", "2", "5", "10"),
        setChoice = { "settings put global $key $it" }, persist = false)

private fun sf(title: String, summary: String, code: Int) =
    Opt(title, summary, null, { false },
        "service call SurfaceFlinger $code i32 1", "service call SurfaceFlinger $code i32 0")

val OPTIONS: List<Opt> = listOf(
    /* 1  */ setting("Developer options", "Master switch for developer settings", "global", "development_settings_enabled"),
    /* 2  */ setting("USB debugging", "Debug mode when USB is connected (turning off may stop Shizuku)", "global", "adb_enabled"),
    /* 3  */ setting("Wireless debugging", "Debug mode when Wi-Fi is connected", "global", "adb_wifi_enabled"),
    /* 4  */ Opt("Disable adb authorization timeout", "Don't auto-revoke adb keys after 7 days",
        "settings get secure adb_allowed_connection_time", { it.trim() == "0" },
        "settings put secure adb_allowed_connection_time 0", "settings put secure adb_allowed_connection_time 604800000"),
    /* 5  */ Opt("Stay awake", "Screen never sleeps while charging", "settings get global stay_on_while_plugged_in",
        { it.trim() != "0" && it.trim() != "null" }, "settings put global stay_on_while_plugged_in 7",
        "settings put global stay_on_while_plugged_in 0"),
    /* 6  */ setting("Show taps", "Show visual feedback for touches", "system", "show_touches"),
    /* 7  */ setting("Pointer location", "Screen overlay showing current touch data", "system", "pointer_location"),
    /* 8  */ setting("Don't keep activities", "Destroy every activity as soon as the user leaves it", "global", "always_finish_activities"),
    /* 9  */ setting("Show all ANRs", "Show 'App Not Responding' for background apps", "secure", "anr_show_background"),
    /* 10 */ scale("Window animation scale", "window_animation_scale"),
    /* 11 */ scale("Transition animation scale", "transition_animation_scale"),
    /* 12 */ scale("Animator duration scale", "animator_duration_scale"),
    /* 13 */ prop("Show layout bounds", "Show clip bounds, margins, etc.", "debug.layout", "true", "false"),
    /* 14 */ prop("Debug GPU overdraw", "Show overdraw areas on screen", "debug.hwui.overdraw", "show", "false"),
    /* 15 */ prop("Profile GPU rendering", "Show frame time as on-screen bars", "debug.hwui.profile", "visual_bars", "false"),
    /* 16 */ prop("Show hardware layers updates", "Flash hardware layers green when they update", "debug.hwui.show_layers_updates", "true", "false"),
    /* 17 */ sf("Show surface updates", "Flash entire window surfaces when they update", 1002),
    /* 18 */ sf("Disable HW overlays", "Always use GPU for screen compositing", 1008),
    /* 19 */ prop("Force 4x MSAA", "Enable 4x MSAA in OpenGL ES 2.0 apps", "debug.egl.force_msaa", "true", "false"),
    /* 20 */ setting("Wi-Fi verbose logging", "Enable Wi-Fi verbose logging", "global", "wifi_verbose_logging_enabled"),
    /* 21 */ setting("Mobile data always active", "Keep mobile data on even when Wi-Fi is active", "global", "mobile_data_always_on"),
    /* 22 */ setting("Enable freeform windows", "Allow freeform windows (experimental)", "global", "enable_freeform_support"),
    /* 23 */ setting("Force activities to be resizable", "Make all activities resizable for multi-window", "global", "force_resizable_activities"),
    /* 24 */ Opt("Override force-dark", "Force dark mode on all apps", "cmd uimode night",
        { it.contains("yes", true) }, "cmd uimode night yes", "cmd uimode night no", persist = false),
    /* 25 */ Opt("Simulate color space: monochromacy", "Grayscale display for accessibility testing",
        "settings get secure accessibility_display_daltonizer_enabled", { it.trim() == "1" },
        "settings put secure accessibility_display_daltonizer 0; settings put secure accessibility_display_daltonizer_enabled 1",
        "settings put secure accessibility_display_daltonizer_enabled 0"),
)
