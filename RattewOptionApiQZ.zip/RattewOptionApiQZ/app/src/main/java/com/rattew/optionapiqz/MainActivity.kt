package com.rattew.optionapiqz

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : AppCompatActivity() {

    private class Row(val opt: Opt, val summary: TextView, val sw: SwitchCompat?) {
        var on = false
        var value = ""
    }

    private lateinit var status: TextView
    private lateinit var oemInfo: TextView
    private lateinit var rootInfo: TextView
    private val rows = mutableListOf<Row>()
    private val prefs by lazy { getSharedPreferences("cache", MODE_PRIVATE) }

    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { if (this::status.isInitialized) onShizukuChanged() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { if (this::status.isInitialized) onShizukuChanged() } }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { if (this::status.isInitialized) onShizukuChanged() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val oldHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            prefs.edit().putString("crash", android.util.Log.getStackTraceString(e)).commit()
            oldHandler?.uncaughtException(t, e)
        }
        val crash = prefs.getString("crash", null)
        if (crash != null) { showCrash(crash); return }
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        onShizukuChanged()
    }

    private fun showCrash(trace: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(40), dp(20), dp(20)) }
        box.addView(text("App crashed last time. Screenshot this and send it:", 16f, Color.parseColor("#FF8A80"), true))
        box.addView(text(trace.take(2500), 11f).apply { setTextIsSelectable(true) })
        box.addView(button("Clear and try again") { prefs.edit().remove("crash").apply(); recreate() })
        setContentView(ScrollView(this).apply { addView(box) })
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun text(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun header(s: String) = text(s, 13f, Color.parseColor("#8AB4F8"), true).apply {
        setPadding(dp(20), dp(24), dp(20), dp(6))
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(root); isFillViewport = true }
        setContentView(scroll)

        // Title block with the Rattew image
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(12))
        }
        top.addView(ImageView(this).apply {
            setImageResource(R.drawable.rattew)
            layoutParams = LinearLayout.LayoutParams(dp(84), dp(84))
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(42).toFloat(); setColor(Color.WHITE) }
        })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        titles.addView(text("Rattew Option Api QZ", 22f, bold = true))
        status = text("", 13f, Color.LTGRAY)
        titles.addView(status)
        top.addView(titles)
        root.addView(top)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(16), 0, dp(16), 0) }
        actions.addView(button("Grant / open Shizuku") { grantShizuku() })
        actions.addView(button("Refresh") { refreshAll() })
        root.addView(actions)

        val modeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val rShizuku = RadioButton(this).apply { text = "Shizuku mode"; setTextColor(Color.WHITE); id = View.generateViewId() }
        val rRoot = RadioButton(this).apply { text = "Root mode"; setTextColor(Color.WHITE); id = View.generateViewId() }
        modeGroup.addView(rShizuku); modeGroup.addView(rRoot)
        modeGroup.check(rShizuku.id)
        modeGroup.setOnCheckedChangeListener { _, id -> Shell.useRoot = id == rRoot.id; onShizukuChanged() }
        root.addView(modeGroup)

        // OEM unlock
        root.addView(header("OEM UNLOCK"))
        oemInfo = text("Reading bootloader status…", 14f, Color.LTGRAY).apply { setPadding(dp(20), 0, dp(20), dp(8)) }
        root.addView(oemInfo)
        val oem = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), 0) }
        oem.addView(button("Open system \"OEM unlocking\" toggle") {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
            catch (e: Exception) { toast("Cannot open Developer options: ${e.message}") }
        })
        oem.addView(button("Try allow OEM unlock (root, best effort)") {
            bg { val r = Shell.runRoot("setprop sys.oem_unlock_allowed 1; settings put global oem_unlock_allowed 1"); ui { toast(if (r.code == 0) "Sent. Check the system toggle." else "Failed: ${r.out}"); loadOem() } }
        })
        oem.addView(button("Reboot to bootloader") {
            confirm("Reboot to bootloader?", "Then run on your PC:\nfastboot flashing unlock\n\nUnlocking WIPES all data and may void warranty.") {
                bg { Shell.run("reboot bootloader") }
            }
        })
        root.addView(oem)

        // Options
        root.addView(header("DEBUGGING & DRAWING  (25 options)"))
        OPTIONS.forEachIndexed { i, opt -> root.addView(buildRow(i, opt)) }

        // Root module
        root.addView(header("ROOT MODULE  (Magisk / KernelSU / APatch)"))
        rootInfo = text("Not checked yet", 14f, Color.LTGRAY).apply { setPadding(dp(20), 0, dp(20), dp(8)) }
        root.addView(rootInfo)
        val rm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(48)) }
        rm.addView(button("Check root") { checkRoot() })
        rm.addView(button("Install boot module with my ON options") { installModule() })
        rm.addView(button("Remove module (on next reboot)") { removeModule() })
        rm.addView(button("Root extra: adb over TCP :5555") {
            bg { val r = Shell.runRoot("setprop service.adb.tcp.port 5555; stop adbd; start adbd"); ui { toast(if (r.code == 0) "adb tcp 5555 enabled" else r.out) } }
        })
        rm.addView(button("Root extra: reboot") { confirm("Reboot now?", "") { bg { Shell.runRoot("reboot") } } })
        root.addView(rm)
    }

    private fun buildRow(index: Int, opt: Opt): View {
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
            isClickable = true
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(opt.title, 16f))
        val sum = text(opt.summary, 13f, Color.GRAY)
        col.addView(sum)
        line.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val sw = if (opt.choices == null) SwitchCompat(this) else null
        val row = Row(opt, sum, sw)
        rows.add(row)
        if (sw != null) {
            line.addView(sw)
            sw.setOnClickListener { setOn(index, sw.isChecked) }
            line.setOnClickListener { sw.performClick() }
        } else {
            line.setOnClickListener {
                AlertDialog.Builder(this).setTitle(opt.title)
                    .setItems(opt.choices!!.toTypedArray()) { _, which -> applyChoice(row, opt.choices[which]) }.show()
            }
        }
        return line
    }

    // ---------------------------------------------------------------- Logic

    private fun onShizukuChanged() {
        val s = Shizuku.pingBinder().let { Shell.shizukuState() }
        status.text = if (Shell.useRoot) "Mode: ROOT (su)" else when (s) {
            0 -> "Shizuku: not running — start it first"
            1 -> "Shizuku: running, permission needed"
            else -> "Shizuku: connected ✔"
        }
        refreshAll()
    }

    private fun grantShizuku() {
        when (Shell.shizukuState()) {
            1 -> Shizuku.requestPermission(100)
            0 -> packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
                ?: toast("Install Shizuku from Play Store / GitHub first")
            else -> toast("Already connected")
        }
    }

    private fun refreshAll() {
        loadOem()
        bg {
            rows.forEachIndexed { i, r ->
                val o = r.opt
                if (o.read == null) {
                    val on = prefs.getBoolean("opt$i", false)
                    ui { r.on = on; r.sw?.isChecked = on }
                } else {
                    val res = Shell.run(o.read)
                    if (res.code == 0) ui {
                        if (o.choices != null) { r.value = res.out.trim(); r.summary.text = "Current: ${r.value}" }
                        else { r.on = o.isOn(res.out); r.sw?.isChecked = r.on }
                    }
                }
            }
        }
    }

    private fun setOn(i: Int, on: Boolean) {
        val r = rows[i]
        bg {
            val res = Shell.run(if (on) r.opt.on else r.opt.off)
            ui {
                if (res.code != 0) { toast("Failed: ${res.out}"); r.sw?.isChecked = !on }
                else { r.on = on; prefs.edit().putBoolean("opt$i", on).apply() }
            }
        }
    }

    private fun applyChoice(r: Row, v: String) = bg {
        val res = Shell.run(r.opt.setChoice!!(v))
        ui { if (res.code == 0) { r.value = v; r.summary.text = "Current: $v" } else toast("Failed: ${res.out}") }
    }

    private fun loadOem() = bg {
        val locked = Shell.run("getprop ro.boot.flash.locked").out.trim()
        val vb = Shell.run("getprop ro.boot.verifiedbootstate").out.trim()
        val sup = Shell.run("getprop ro.oem_unlock_supported").out.trim()
        val allowed = Shell.run("getprop sys.oem_unlock_allowed").out.trim()
        val state = when (locked) { "1" -> "LOCKED"; "0" -> "UNLOCKED"; else -> "unknown" }
        ui {
            oemInfo.text = "Bootloader: $state\nVerified boot: ${vb.ifEmpty { "?" }}\n" +
                "OEM unlock supported: ${sup.ifEmpty { "?" }}   allowed flag: ${allowed.ifEmpty { "?" }}"
        }
    }

    // ---------------------------------------------------------------- Root module

    private fun checkRoot() = bg {
        val r = Shell.runRoot("id")
        val ver = Shell.runRoot("magisk -v 2>/dev/null || ksud -V 2>/dev/null || echo unknown-manager").out
        ui { rootInfo.text = if (r.out.contains("uid=0")) "Root: YES ✔\nManager: $ver" else "Root: NO (${r.out})" }
    }

    private val modDir = "/data/adb/modules/rattew_optionapi"

    private fun installModule() = confirm("Install boot module?",
        "Options that are currently ON will be re-applied at every boot. Needs root.") {
        val cmds = rows.filter { it.on && it.opt.persist }.map { it.opt.on }
        val script = buildString {
            appendLine("#!/system/bin/sh")
            appendLine("# Generated by Rattew Option Api QZ")
            appendLine("until [ \"\$(getprop sys.boot_completed)\" = \"1\" ]; do sleep 2; done")
            appendLine("sleep 5")
            cmds.forEach { appendLine(it) }
        }
        val prop = "id=rattew_optionapi\nname=Rattew Option Api QZ Module\nversion=v1.0\nversionCode=1\n" +
            "author=Rattew\ndescription=Re-applies Developer Option toggles from Rattew Option Api QZ at boot (${cmds.size} commands)\n"
        val tmpS = File(cacheDir, "service.sh").apply { writeText(script) }
        val tmpP = File(cacheDir, "module.prop").apply { writeText(prop) }
        bg {
            val r = Shell.runRoot("mkdir -p $modDir && rm -f $modDir/remove && cp ${tmpS.path} $modDir/service.sh && " +
                "cp ${tmpP.path} $modDir/module.prop && chmod 755 $modDir/service.sh && chmod 644 $modDir/module.prop")
            ui { toast(if (r.code == 0) "Module installed (${cmds.size} commands). Reboot to activate." else "Failed: ${r.out}"); checkRoot() }
        }
    }

    private fun removeModule() = bg {
        val r = Shell.runRoot("touch $modDir/remove")
        ui { toast(if (r.code == 0) "Marked for removal. Reboot." else "Failed: ${r.out}") }
    }

    // ---------------------------------------------------------------- helpers

    private fun bg(block: () -> Unit) {
        Thread {
            try { block() } catch (e: Throwable) { runOnUiThread { toast("Error: ${e.message}") } }
        }.start()
    }
    private fun ui(block: () -> Unit) = runOnUiThread(block)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun confirm(t: String, m: String, ok: () -> Unit) =
        AlertDialog.Builder(this).setTitle(t).setMessage(m)
            .setPositiveButton("Continue") { _, _ -> ok() }.setNegativeButton("Cancel", null).show()
}
