package com.rattew.optionapiqz

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Runs shell commands either through Shizuku (adb/shell privileges) or through su (root). */
object Shell {
    var useRoot = false

    data class Res(val code: Int, val out: String)

    /** 0 = Shizuku not running, 1 = running but no permission, 2 = ready */
    fun shizukuState(): Int {
        if (!Shizuku.pingBinder() || Shizuku.isPreV11()) return 0
        return if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
    }

    fun run(cmd: String): Res = if (useRoot) runRoot(cmd) else runShizuku(cmd)

    fun runRoot(cmd: String): Res = try {
        read(Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)))
    } catch (e: Exception) {
        Res(-1, e.message ?: "su not available")
    }

    // Shizuku.newProcess is private in API 13+, so call it by reflection (same trick Shizuku's demo uses).
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).also { it.isAccessible = true }
    }

    private fun runShizuku(cmd: String): Res {
        if (shizukuState() != 2) return Res(-1, "Shizuku is not ready")
        return try {
            read(newProcess.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process)
        } catch (e: Exception) {
            Res(-1, e.cause?.message ?: e.message ?: "error")
        }
    }

    private fun read(p: Process): Res {
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        return Res(code, (out + err).trim())
    }
}
