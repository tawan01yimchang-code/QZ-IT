# Rattew Option Api QZ
Developer-Options style app (25 options + OEM unlock menu + root boot module) driven by Shizuku.

Build: open this folder in Android Studio (Koala+), let it sync (it creates the Gradle wrapper), Run.
Use: install Shizuku, start it (Wireless debugging or root), open the app, tap "Grant / open Shizuku".
Root mode: switch to "Root mode" and grant su. The ROOT MODULE section writes a Magisk/KernelSU/APatch module to /data/adb/modules/rattew_optionapi that re-applies your ON options at boot.
OEM unlock: Android does not allow apps to flip the real OEM-unlocking switch; the app shows status, opens the system toggle, tries a root flag, and reboots to bootloader for `fastboot flashing unlock`.

## Build APK without a PC
Upload this project to a GitHub repo -> Actions tab -> "Build APK" -> download artifact RattewOptionApiQZ-apk (contains app-debug.apk).
